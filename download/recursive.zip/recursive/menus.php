<?php
$menus = Array
    (
    1 => Array
        (
        'id' => 1,
        'parent' => 0,
        'title' => 'Page 1'
    ),
    2 => Array
        (
        'id' => 2,
        'parent' => 0,
        'title' => 'Page 2',
    ),
    3 => Array
        (
        'id' => 3,
        'parent' => 0,
        'title' => ' Page 3'
    )
    ,
    4 => Array
        (
        'id' => 4,
        'parent' => 0,
        'title' => 'Page 4',
    )
    ,
    5 => Array
        (
        'id' => 5,
        'parent' => 0,
        'title' => 'Page 5',
    )
    ,
    6 => Array
        (
        'id' => 6,
        'parent' => 1,
        'title' => 'Page 1-1'
    )
    ,
    7 => Array
        (
        'id' => 7,
        'parent' => 1,
        'title' => 'Page 1-2'
    )
    ,
    8 => Array
        (
        'id' => 8,
        'parent' => 1,
        'title' => 'Page 1-3',
    )
    ,
    9 => Array
        (
        'id' => 9,
        'parent' => 2,
        'title' => 'Page 2-1',
    )
    ,
    10 => Array
        (
        'id' => 10,
        'parent' => 2,
        'title' => 'Page 2-2',
    )
    ,
    11 => Array
        (
        'id' => 11,
        'parent' => 2,
        'title' => 'Page 2-3',
    )
    ,
    12 => Array
        (
        'id' => 12,
        'parent' => 3,
        'title' => 'Page 3-1',
    )
    ,
    13 => Array
        (
        'id' => 13,
        'parent' => 3,
        'title' => 'Page 3-2'
    )
    ,
    14 => Array
        (
        'id' => 14,
        'parent' => 4,
        'title' => 'Page 4-1'
    )
    ,
    15 => Array
        (
        'id' => 15,
        'parent' => 6,
        'title' => 'Page 1-1-1',
    )
    ,
    16 => Array
        (
        'id' => 16,
        'parent' => 6,
        'title' => 'Page 1-1-2',
    )
    ,
    17 => Array
        (
        'id' => 17,
        'parent' => 6,
        'title' => 'Page 1-1-3',
    )
    ,
    18 => Array
        (
        'id' => 18,
        'parent' => 7,
        'title' => 'Page 1-2-1',
    )
    ,
    19 => Array
        (
        'id' => 19,
        'parent' => 7,
        'title' => 'Page 1-2-2',
    )
    ,
    20 => Array
        (
        'id' => 20,
        'parent' => 7,
        'title' => 'Page 1-2-3',
    )
    ,
    21 => Array
        (
        'id' => 21,
        'parent' => 9,
        'title' => 'Page 2-1-1',
    )
    ,
    22 => Array
        (
        'id' => 22,
        'parent' => 9,
        'title' => ' Page 2-1-2'
    )
    ,
    23 => Array
        (
        'id' => 23,
        'parent' => 9,
        'title' => 'Page 2-1-3'
    )
);


function generateArr($array) {
    foreach ($array as $key => $value) {
        $menus[$value['parent']][$key] = $value['title'];
    }
    return ($menus);
}
function getTreeList($key, $arr){
    echo '<ul>';
    foreach($arr[$key] as $in => $val){
        if(array_key_exists($in, $arr)){
            echo '<li class="has-child">';
            echo $val;
            getTreeList($in, $arr);
        }else{
            echo '<li>';
            echo $val;
        }
        echo '</li>';
    }
    echo '</ul>';
}
$newArr = generateArr($menus);
?>
<?php echo getTreeList(0, $newArr); ?>