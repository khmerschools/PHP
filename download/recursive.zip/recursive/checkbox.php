<?php
$menus = Array
    (
    1 => Array
        (
        'id' => 1,
        'parent' => 0,
        'title' => 'Page 1'
    ),
    2 => Array
        (
        'id' => 2,
        'parent' => 0,
        'title' => 'Page 2',
    ),
    3 => Array
        (
        'id' => 3,
        'parent' => 2,
        'title' => ' Page 3'
    )
    ,
    4 => Array
        (
        'id' => 4,
        'parent' => 2,
        'title' => 'Page 4',
    )
);

function generateArr($array) {
    foreach ($array as $key => $value) {
        $menus[$value['parent']][$key] = $value['title'];
    }
    return ($menus);
}

function getTreeList($key, $arr) {
    echo '<div class="list">';
    foreach ($arr[$key] as $in => $val) {
        if (array_key_exists($in, $arr)) {
            echo '<label>';
            echo '<input type="checkbox" name="checkbox[]" value="' . $in . '" />';
            echo $val;
            echo '</label>';
            getTreeList($in, $arr);
        } else {
            echo '<label>';
            echo '<input type="checkbox" name="checkbox[]" value="' . $in . '" />';
            echo $val;
            echo '</label>';
        }
    }
    echo '</div>';
}

$newArr = generateArr($menus);
?>
<?php echo getTreeList(0, $newArr); ?>

<style type="text/css">
    .list .list{
        margin-left: 20px;
    }
    label{
        display: block;
    }
</style>