<?php
$menus = Array
    (
    1 => Array
        (
        'id' => 1,
        'parent' => 0,
        'title' => 'Page 1'
    ),
    2 => Array
        (
        'id' => 2,
        'parent' => 0,
        'title' => 'Page 2',
    ),
    3 => Array
        (
        'id' => 3,
        'parent' => 2,
        'title' => ' Page 3'
    )
    ,
    4 => Array
        (
        'id' => 4,
        'parent' => 2,
        'title' => 'Page 4',
    )
);
function generateArr($array) {
    foreach ($array as $key => $value) {
        $menus[$value['parent']][$key] = $value['title'];
    }
    return $menus;
}

function getTreeList($key, $arr, $level=1){
    foreach($arr[$key] as $in => $val){
        if(array_key_exists($in, $arr)){
            echo '<option>';
            echo getInden($level,'&nbsp;&nbsp;&nbsp;').$val;
            echo '</option>';
            getTreeList($in, $arr, $level+1);
        }else{
            echo '<option>';
            echo getInden($level,'&nbsp;&nbsp;&nbsp;').$val;
            echo '</option>';
        }
    }
}

function getInden($level, $type='&nbsp;'){
    $indenType = '';
    for($i=0;$i<$level; $i++){
        $indenType .= $type;
    }
    return $indenType;
}
$newArr = generateArr($menus);

?>
<select>
<?php echo getTreeList(0, $newArr,0); ?>
</select>